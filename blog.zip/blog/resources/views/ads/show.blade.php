<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="layui/css/layui.css"  media="all">
    <link rel="stylesheet" href="css/page.css">
    <title>Document</title>
</head>
<body>
    
<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
    <legend>管理展示</legend>
</fieldset>
 
<div class="layui-form">
  <table class="layui-table">

<form action="show">
    <div class="demoTable">
    搜索ID：
        <div class="layui-inline">
            <input class="layui-input" name="title" id="title" autocomplete="off">
        </div>
            <button class="layui-btn" data-type="reload">搜索</button>
    </div>
</form>

      <tr>
        <th>ID</th>
        <th>标题</th>
        <th>关键词</th>
        <th>内容</th>
        <th>图片</th>
        <th>操作</th>
      </tr> 
    @foreach ($arr as $v)
      <tr del_id={{ $v->id }} >
        <td>{{ $v->id }}</td>
        <td>{{ $v->title }}</td>
        <td>{{ $v->keyword }}</td>
        <td>{{ $v->content }}</td>
        <td><img src="http://www.upload.com/{{$v->img}}" width="50" height="50"></td>
        <td>
            <a href="add" class="layui-btn">增加</a>
            <a href="javascript:;" class="layui-btn del">删除</a>
            <a href="javascript:;" class="layui-btn update">编辑</a>
        </td>
      </tr>
      @endforeach
  </table>
  {{$arr->appends(['title'=>$title])->links()}}
</div>
</body>
</html>

<script src="js/jquery-3.2.1.min.js"></script>
<script src="layui/layui.js"></script>
<script>
layui.use("layer",function() {
    var layer = layui.layer;
    $(function () {
        $('.del').click(function () {
            var _this = $(this);
            var del_id = _this.parents('tr').attr('del_id');
            $.ajax({
                type: "POST",
                data: {del_id : del_id},
                url: "del",
                success: function (msg) {
                    if (msg.status == 1) {
                        layer.msg(msg.msg);
                        // alert('删除成功');
                        window.location.reload();
                    } else {
                        layer.msg(msg.msg);
                        // alert('删除失败');
                        location.href='show';
                    }
                }
            })
        })
        $('.update').click(function(){
            var _this=$(this)
            var del_id=_this.parents('tr').attr('del_id')
            location.href='upd?del_id='+del_id;

        });
    })
})
</script>