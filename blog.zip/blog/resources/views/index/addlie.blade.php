@foreach($info as $v)
      <div class="index-pro1-list" >
      
       <dl>
       
        <dt><a href="proinfo?goods_id={{$v->goods_id}}"><img src="{{URL::asset('goodsimg/'.$v->goods_img)}}" /></a></dt>
        <dd class="ip-text"><a href="proinfo?goods_id={{$v->goods_id}}">{{$v->goods_name}}</a><span></span></dd>
        <dd class="ip-price"><strong>¥{{$v->goods_selfprice}}</strong> <span>¥599</span></dd>
        
       </dl>
       
      </div>
@endforeach 