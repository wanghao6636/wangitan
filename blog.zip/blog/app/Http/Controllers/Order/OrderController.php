<?php

namespace App\Http\Controllers\Order;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class OrderController extends Controller
{
    /**订单提交 */
    public function orderadd(Request $request){
        $session_id = $request->session()->get('user_id');
        if (empty($session_id)) {
            return redirect('login');
        }
        $order_amount = $request->input('order_amount');
        $goods_id = $request->input('goods_id');
        $goods_id = ltrim($goods_id,',');
        $goods_id = explode(',',$goods_id);
        if (empty($goods_id)) {
            return redirect('index');
        }
        $res = DB::table('cart')->whereIn('goods_id',$goods_id)->where('user_id',$session_id)->get();
        foreach($res as $v){
            if ($v->goods_status!=1) {
                return redirect('goods');
            }
        }
        $order_number = date("YmdHis",time()).rand(1000,9999);
        // dd($order_number);
        $orderInfo = [
            'user_id'=>$session_id,
            'order_amount'=>$order_amount,
            'order_number'=>$order_number,
            'order_status'=>1,
            'pay_status'=>1,
            'pay_type'=>1,
            'pay_time'=>time(),
        ];
        // dd($order);
        $order_id = DB::table('order')->insertGetId($orderInfo);
        // var_dump($order);
        $data = DB::table('cart')
            ->whereIn('cart.goods_id',$goods_id)
            ->where('user_id',$session_id)
            ->join('goods','cart.goods_id','=','goods.goods_id')
            ->get();
            
        foreach($data as $v){
            $order_detail = [
                'user_id'=>$session_id,
                'order_number'=>$order_number,
                'order_id'=>$order_id,
                'buy_number'=>$v->buy_number,
                'goods_selfprice'=>$v->goods_selfprice,
                'goods_img'=>$v->goods_img,
                'goods_status'=>$v->goods_status,
                'goods_id'=>$v->goods_id,
                'goods_name'=>$v->goods_name,
            ];
            // var_dump($order_detail);
            $arr = DB::table('order_detail')->insert($order_detail);
        }
        if ($arr) {

            $arr = ['status'=>1,'msg'=>'订单提交成功','order_id'=>$order_id];
                
            // $cartUpdate=[
            //     'is_del'=>2,
            //     'buy_number'=>0
            // ];

            // DB::table('cart')->where('user_id',$session_id)->whereIn('goods_id',$goods_id)->update($cartUpdate);
            return $arr;
        }
    }


/**订单展示 */
    public function orderdet(Request $request){
        $order_id=$request->input('order_id');
        $res = DB::table('goods')->get();
        $arr = DB::table('order_detail')->get();
        $amount = DB::table('order')->where('pay_status',1)->get();
        // $arr = DB::table('order_detail')->join('goods','order_detail.goods_id','=','goods.goods_id')->get();
        // var_dump($res);
        // var_dump($arr);exit;
        // dd($amount);
        $detail = DB::table('order_address')->where('status',1)->first();
        return view('order.order',['arr'=>$arr,'$res'=>$res,'amount'=>$amount,'detail'=>$detail,'order_id'=>$order_id]);
    }



    public function showindex(){
        return view("order.showindex");
    }

    public function showpay(Request $request){
        $order_id = $request->input('order_id');
//        print_r($order_id);exit;
        $res = DB::table('order')->join('order_detail','order_detail.order_id','=','order.order_id')->first();
        $arr = DB::table('order')->where('order_id',$order_id)->first();
//        print_r($arr);exit;

        return view("order.showpay",['arr'=>$arr,'res'=>$res]);
    }

    public function sell(Request $request){
        $arr=$request->input();
//        print_r($arr);exit;
        $orderNo=$arr['WIDout_trade_no'];
        $orderName=$arr['WIDsubject'];
        $orderMoney=$arr['WIDtotal_amount'];
        $orderDesc=$arr['WIDbody'];
        $timeout_express="1m";

        $payRequestBuilder = new \AlipayTradeWapPayContentBuilder();
        $payRequestBuilder->setBody($orderDesc);
        $payRequestBuilder->setSubject($orderName);
        $payRequestBuilder->setOutTradeNo($orderNo);
        $payRequestBuilder->setTotalAmount($orderMoney);
        $payRequestBuilder->setTimeExpress($timeout_express);
        $configPath=app_path()."/extend/alipay/config.php";
        $config=require_once($configPath);
        $payResponse = new \AlipayTradeService($config);
        $result=$payResponse->wapPay($payRequestBuilder,$config['return_url'],$config['notify_url']);

        return ;
    }

    public function result(){
        echo "支付成功";
    }

    /** 异步支付 */
    public function tell(Request $request){

        $arr=$_REQUEST;
        $str=var_export($arr,true);//初始化
        file_put_contents("/tmp/alipay.log",$str,FILE_APPEND); //生成日志

//        Log::channel('alipay')->info($str);

        $configPath=app_path()."/extend/alipay/config.php";
        $config=require_once($configPath);

        $alipaySevice=new \AlipayTradeService($config);
        $result=$alipaySevice->check($arr);

        $result = true;
        if($result) {//验证成功

            $out_trade_no = $_POST['out_trade_no'];

            $order_amount = $_POST['total_amount'];

            if($arr['trade_status'] == 'TRADE_FINISHED') {

            }
            else if ($_POST['trade_status'] == 'TRADE_SUCCESS') {

                $orderWhere=[
                    'order_number'=>$out_trade_no, //订单编号
                    'order_amount'=>$order_amount  //总价额
                ];
                $orderInfo=DB::table('order')->where($orderWhere)->first();

//                $strl=var_export($orderInfo,true);
//                file_put_contents("/tmp/a.log",$strl,FILE_APPEND);
                
                if($orderInfo){
                    //修改订单表的状态
                    $orderUpdate=DB::table('order')->where('order_number',$out_trade_no)->update(['pay_status'=>2]);
                    //修改订单详情表的数据状态
                    $orderDetailUpdate=DB::table('order_detail')->where('order_number',$out_trade_no)->update(['goods_status'=>2]);
                    //查询出商品订单详情表的数据并修改库存
                    $orderDetailInfo=DB::table('order_detail')->where('order_number',$out_trade_no)->get();
                    foreach($orderDetailInfo as $k=>$v){
                        $goodsInfo=DB::table('goods')->where('goods_id',$v->goods_id)->first();
                        $goods_num=$goodsInfo->goods_num-$v->buy_number;
                        $goodsUpdate=DB::table('goods')->where('goods_id',$v->goods_id)->update(['goods_num'=>$goods_num]);
                    }
                }
            }

            echo "success";		//请不要修改或删除

        }else {
            //验证失败
            echo "fail";	//请不要修改或删除

        }
    }
}
