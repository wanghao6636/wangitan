<?php

namespace App\Http\Controllers\Goods;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class CartController extends Controller
{
    public function cart(Request $request){
        $session_id = $request->session()->get('user_id');
        // var_dump($session_id);
        if ($session_id) {
            
            $arr = DB::table('cart')->join('goods','goods.goods_id','=','cart.goods_id')->where('user_id',$session_id)->where('is_del',1)->get();
            // var_dump($arr);die;
            $goodsWhere=[
                'goods_hot'=>1
            ];
            $res=DB::table('goods')->where($goodsWhere)->orderBy('goods_salenum','desc')->limit(4)->get();
            return view('goods.cart',['arr'=>$arr,'res'=>$res]);
        }else{
            echo '请先登录';
            return redirect('login');
        }
    }

    /**减 */
    public function cartmin(Request $request){
            $session_id = $request->session()->get('user_id');
        if ($session_id) {
            $id = $request->input('id');
            $buy_number = $request->input('buy_number');
            // dd($buy_number);
            
            $arr = DB::table('cart')->where(['id'=>$id,'user_id'=>$session_id])->first();
            // dd($arr);
            $info = [
                'buy_number'=>$buy_number,
            ];
            $arr = DB::table('cart')->where(['id'=>$id,'user_id'=>$session_id])->update($info);
            // dd($arr);
            if ($arr) {
                $arr = ['status'=>1,'msg'=>'修改成功'];
                return $arr;
            }else{
                $arr = ['status'=>0,'msg'=>'购物车最少为一件商品'];
                return $arr;
            } 
        }else{
            return  array('status'=>3,"msg"=>"请先登录");
        }
    }
    /**加 */
    public function cartadds(Request $request){
            $session_id = $request->session()->get('user_id');
        if ($session_id) {
            $id = $request->input('id');
            $buy_number = $request->input('buy_number',0,'intval');
            // $goods_id = $request->input('goods_id');
            // dd($goods_id);
            // $goodsWhere=[
            //     'goods_id'=>$goods_id
            // ];
            // dd($goodsWhere);
            // $goodsInfo = DB::table('goods')->where($goodsWhere)->first();

            $arr = DB::table('cart')->where(['id'=>$id,'user_id'=>$session_id])->first();
            // $arr = $arr->buy_number;
            // if ($arr > $goods_num) {
            //     $arr = ['status'=>4,'msg'=>'已超过库存'];
            //     return $arr;
            // }
            // dd($arr);
            $info = [
                'buy_number'=>$buy_number,
            ];
            $arr = DB::table('cart')->where(['id'=>$id,'user_id'=>$session_id])->update($info);
            
            if ($arr) {
                $arr = ['status'=>1,'msg'=>'修改成功'];
                return $arr;
            }else{
                $arr = ['status'=>0,'msg'=>'修改失败'];
                return $arr;
            }
        }else{
            return  array('status'=>3,"msg"=>"请先登录");
        }
    }

    /**删除（单） */
    public function cartdel(Request $request){
        $session_id = $request->session()->get('user_id');
        if ($session_id) {
            $id = $request->input('id',0,'intval');
            if (empty($id)) {
                $arr = ['status'=>0,'msg'=>'请选择要删除的商品'];
                return $arr;
            }
            $info = [
                'is_del'=>2,
                'buy_number'=>0
            ];
            $arr = DB::table('cart')->where('id',$id)->where('user_id',$session_id)->update($info);
            // var_dump($arr);
            if ($arr) {
                $arr = ['status'=>1,'msg'=>'已从购物车里移除'];
                return $arr;
            }else{
                $arr = ['status'=>0,'msg'=>'购物车移除失败'];
                return $arr;
            }
        }else{
            return array('status'=>3,'msg'=>'请先登录');
        }
    }

    /**删除（批） */
    public function delall(Request $request){
        $session_id = $request->session()->get('user_id');
        if ($session_id) {
            $goods_id = $request->input('goods_id');
            $goods_id = ltrim($goods_id,',');
            $goods_id = explode(',',$goods_id);
            // print_r($goods_id);exit;
            $info = [
                'is_del'=>2,
                'buy_number'=>0
            ];
            $arr = DB::table('cart')->whereIn('goods_id',$goods_id)->where('user_id',$session_id)->update($info);
            // var_dump($arr);
            if ($arr) {
                $arr = ['status'=>1,'msg'=>'已从购物车里移除'];
                return $arr;
            }else{
                $arr = ['status'=>0,'msg'=>'购物车移除失败'];
                return $arr;
            }
        }else{
            return array('status'=>3,'msg'=>'请先登录');
        }
        
    }


}