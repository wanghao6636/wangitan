<?php

namespace App\Http\Controllers\Lianxi;

use Illuminate\Support\Facades\DB;
use App\Http\Requests\StoreLianxiPost;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class TextController extends Controller
{

/**添加展示 */
    public function show(){
        return view('lianxi.show');
    }

/*添加*/
    public function add(StoreLianxiPost $request){
        $info = $request->all();
        $info['img'] = $this->upload($request,'img');
        $info['pwd'] = encrypt($info['pwd']);
        // dd($info);
            // unset($info['_token']);
            unset($info['pwds']);
        $arr = DB::table('lianxi')->insert($info);
        if ($arr){
            echo 1;
           return redirect('lists');
        }else{
            echo 2;
        }
    }

    /**文件上传 */
    public function upload(Request $request,$filename){
        if ($request->hasFile($filename) && $request->file($filename)->isValid()) {
            $photo = $request->file($filename);
            // $extension = $photo->extension();
            // $store_result = $photo->store('photo');
            $store_result = $photo->store('uploads/'.date('Ymd'));
            return $store_result;
        }
        exit('未获取到上传文件或上传过程出错');
    }

/*展示*/
    public function lists(Request $request){
//        $data = $request->input();
        $username=empty($_GET['username'])?"":$_GET['username'];
        $tel=empty($_GET['tel'])?"":$_GET['tel'];

//        dd($username);
//        dd($tel);
        $where = [];
        if ($username??''){
            $where[] = ['name','like',"%$username%"];
        }
        if ($tel??''){
            $where['tel'] = $tel;
        }
        $arr = DB::table('lianxi')
            ->where($where)
            ->select()
            ->paginate(3);
//        dd($arr);
        return view('lianxi.lists',['arr'=>$arr,'username'=>$username,'tel'=>$tel]);

    }

/*删除Ajax*/
    public function del(Request $request){
        $del_id=$request->input('del_id');
        $spl = "delete from lianxi where id=$del_id";
        $arr=DB::delete($spl);
        // print_r($arr);
        if($arr){
            $arr = ['status'=>1,'msg'=>'删除成功'];
            return $arr;
        }else{
            $arr = ['status'=>0,'msg'=>'删除失败'];
            return $arr;
        }
    }

    /**删除 */
    public function delete($id){
        // dd($id);
        $where = [
            'id'=>$id
        ];
        $arr = DB::table('lianxi')->where($where)->delete();
        if ($arr){
            echo 1;
           return redirect('lists');
        }else{
            echo 2;
        }
    }




    
/*修改展示*/
    public function upd(Request $request){
        $del_id=$request->input('del_id');
        $arr = DB::table('lianxi')->where('id','=',$del_id)->first();
//        print_r($arr);
        return view('lianxi.update',['arr'=>$arr]);
    }
/**修改执行 */
    public function update(StoreLianxiPost $request){
        $id=$request->input('id');
//        print_r($del_id);
        $data = $request->input();
        $data['img'] = $this->upload($request,'img');

        if($data['pwd']??''){
            $data['pwd'] = encrypt($data['pwd']);
        }
        $where=[
            'id'=>$id
        ];
        unset($data['pwds']);
//         print_r($data);exit;
        $res = DB::table('lianxi')->where($where)->update($data);
        //  print_r($res);
        if($res){
            echo '1';
            return redirect('lists');
        }else{
            echo '2';
        }
    }

}
