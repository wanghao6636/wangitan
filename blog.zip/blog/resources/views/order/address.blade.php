<!DOCTYPE html>
<html lang="zh-cn">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="Author" contect="http://www.webqin.net">
    <title>三级分销</title>
    <link rel="shortcut icon" href="images/favicon.ico" />
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/response.css" rel="stylesheet">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="http://cdn.bootcss.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="http://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
    <div class="maincont">
     <header>
      <a href="javascript:history.back(-1)" class="back-off fl"><span class="glyphicon glyphicon-menu-left"></span></a>
      <div class="head-mid">
       <h1>收货地址</h1>
      </div>
     </header>
     <div class="head-top">
      <img src="images/head.jpg" />
     </div><!--head-top/-->
     <!-- <form action="" method="post" class="reg-login"> -->
      <div class="lrBox">
       <div class="lrList"><input type="text" placeholder="收货人" name="add_name" id="add_name" /></div>
       <div class="lrList"><input type="text" placeholder="详细地址" name="add_details" id="add_details"/></div>
       <div class="lrList">

        <select class="area" name="add_province" id="add_province">
            <option value="0" selected="selected" selected="selected">请选择...</option>
                @foreach($arr as $v)
                <option value="{{$v->id}}">{{$v->name}}</option>
                @endforeach
        </select>
    
        <select class="area" name="add_city" id="add_city">
            <option value="0" selected="selected" selected="selected">请选择...</option>
        </select>
     
        <select class="area" name="add_district" id="add_district">
            <option value="0" selected="selected" selected="selected">请选择...</option>
        </select>

       </div>
       <div class="lrList"><input type="text" placeholder="手机" name="add_tel" id="add_tel" /></div>
       <!-- <div class="lrList2"><input type="text" placeholder="设为默认地址" id="status" name="status" /> <button>设为默认</button></div> -->
       <div class="lrList2"><button>设为默认</button><input type="checkbox" id="status" name="status" lay-skin="switch">  </div>
      </div><!--lrBox/-->
      <div class="lrSub">
        <a href="javascript:;" class="form">保存</a>
       <!-- <input type="submit"  value="保存" /> -->
      </div>
     <!-- </form> --><!--reg-login/-->
     
     <div class="height1"></div>
     <div class="footNav">
      <dl>
       <a href="index">
        <dt><span class="glyphicon glyphicon-home"></span></dt>
        <dd>微店</dd>
       </a>
      </dl>
      <dl>
       <a href="all">
        <dt><span class="glyphicon glyphicon-th"></span></dt>
        <dd>所有商品</dd>
       </a>
      </dl>
      <dl>
       <a href="car">
        <dt><span class="glyphicon glyphicon-shopping-cart"></span></dt>
        <dd>购物车 </dd>
       </a>
      </dl>
      <dl class="ftnavCur">
       <a href="user.html">
        <dt><span class="glyphicon glyphicon-user"></span></dt>
        <dd>我的</dd>
       </a>
      </dl>
      <div class="clearfix"></div>
     </div><!--footNav/-->
    </div><!--maincont-->
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/style.js"></script>
    <!--jq加减-->
    <script src="js/jquery.spinner.js"></script>
   <script>
	$('.spinnerExample').spinner({});
   </script>
  </body>
</html>
<script src="layui/layui.js"></script>
<script>
$(function(){
    layui.use(['layer'],function(){
        var layer=layui.layer;
        //三级联动
        $('.area').change(function(){
            var _this=$(this);
            _this.nextAll('select').html("<option value='0'>请选择...</option>");
            var id=_this.val();
            $.post(
                "area",
                {id:id},
                function(res){
                    var _option="<option value='0'>请选择...</option>";
                    for(var i in res){
                        _option+="<option value='"+res[i]['id']+"'>"+res[i]['name']+"</option>";
                    }
                    _this.next('select').html(_option);
                },
                'json'
            )
        })
    })
})

layui.use(['form','layer'], function(){
    var form = layui.form();
    var layer=layui.layer;
    $('.form').click(function(){
        _this = $(this);
        var data = {};
        var url = "siteadd";
        var add_name=$('#add_name').val();
        var add_details=$('#add_details').val();
        var add_tel=$('#add_tel').val();
        var add_province=$('#add_province').val();
        var add_city=$('#add_city').val();
        var add_district=$('#add_district').val();
        var status=$('#status').prop('checked');
            if (status == true) {
                status=1;
            }else{
                status=0;
            }
        data.add_name = add_name;
        data.add_details = add_details;
        data.add_tel = add_tel;
        data.add_province = add_province;
        data.add_city = add_city;
        data.add_district = add_district;
        data.status = status;
        $.ajax({
            type : "POST",
            data : data,
            url : url,
            success:function(msg){
                if(msg.status==1){
                layer.msg(msg.msg);
                location.href='orderdet';
            }else if(msg.status==3){
                layer.msg(msg.msg);
                location.href='login';
            }else{
                layer.msg(msg.msg);
                location.href='site';
                }  
            }
        })
    })
})
  
</script>
