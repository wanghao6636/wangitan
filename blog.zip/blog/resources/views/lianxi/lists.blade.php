<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/page.css">
    <title>Document</title>
    <style>
        ul li {
            list-style: none;
            float: left;
            font-size: 30px;
            margin-left: 50px; 
        }
    </style>
</head>
<body>
    <div>用户展示</div><hr>
    <table border=1>
        <form action="lists" >
            <input type="text" name="usernaem" id="usernaem">
            <input type="text" name="tel" id="tel">
            <button>搜索</button>
        </form>
        <tr>
            <td>ID</td>
            <td>账号</td>
            <!-- <td>密码</td> -->
            <td>手机号</td>
            <td>性别</td>
            <td>图片</td>
            <td>操作</td>
        </tr>
        @foreach ($arr as $v)
        <tr del_id={{ $v->id }}>

            <td>{{ $v->id }}</td>
            <td>{{ $v->username }}</td>
            <!-- <td>{{ $v->pwd }}</td> -->
            <td>{{ $v->tel }}</td>
            <td>
                @if ($v->sex == 1)
                    男
                @else
                    女
                @endif
            </td>
            <td><img src="http://www.upload.com/{{$v->img}}" width="50" height="50"></td>
            <td>
                [<a href="delete/{{ $v->id }}">删除</a>]
                [<a href="javascript:;" class="del">删除Ajax</a>]
                [<a href="javascript:;" class="update">修改</a>]
            </td>

        </tr>
        @endforeach
    </table>

    {{$arr->appends(['username'=>$username,'tel'=>$tel])->links()}}

</body>
</html>
<script src="js/jquery-3.2.1.min.js"></script>
<script src="layui/layui.js"></script>
<script>
layui.use("layer",function() {
    var layer = layui.layer;
    $(function () {
        $('.del').click(function () {
            var _this = $(this);
            var del_id = _this.parents('tr').attr('del_id');
            $.ajax({
                type: "POST",
                data: {del_id: del_id},
                url: "del",
                success: function (msg) {
                    if (msg.status == 1) {
                        layer.msg(msg.msg);
                        alert('删除成功');
                        window.location.reload();
                    } else {
                        layer.msg(msg.msg);
                        alert('删除失败');
                        // location.href='site';
                    }
                }
            })
        })
        $('.update').click(function(){
            var _this=$(this)
            var del_id=_this.parents('tr').attr('del_id')
            location.href='upd?del_id='+del_id;

        });
    })
})

</script>
