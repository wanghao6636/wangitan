<?php

namespace App\Http\Controllers\Login;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class LoginController extends Controller
{
    public function login(){
        return view('login.login');
    }

    public function logadd(Request $request){
        $data = $request->input();
        $user_tel = $data['user_tel'];
        $user_pwd = $data['user_pwd'];

        $where = [
            'user_tel'=>$user_tel,
            'user_pwd'=>$user_pwd
        ];
        
        $res = DB::table('index_register')->where($where)->first();

        if (!empty($res)) {
            $user_id=$res->user_id;
            // var_dump($user_id);exit;
            session(['user_id'=>$user_id]);
            return  array('status'=>1,"msg"=>"登录成功");
        }else{
            return  array('status'=>0,"msg"=>"账号或密码错误");
        }

        // var_dump($res);exit;
        
        
       
    }
}
