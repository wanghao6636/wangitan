<?php

namespace App\Http\Controllers\Order;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class SuccessController extends Controller
{
    public function success(Request $request)
    {
        $order_id = $request->input('order_id');
        // var_dump($order_id);
        $where = [
            'pay_status'=>1,
        ];
        $arr = DB::table('order')->where($where)->get();
        return view('order.success',['arr'=>$arr,'order_id'=>$order_id]);
    }
    
}