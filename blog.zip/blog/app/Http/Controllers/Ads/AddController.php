<?php

namespace App\Http\Controllers\Ads;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\StoreAdsPost;
use App\Models\Ads;

class AddController extends Controller
{
    /**添加展示 */
    public function add(){
        return view('ads.add');
    }
    /**添加 */
    public function adddo(StoreAdsPost $request){
        $info = $request->all();
        $info['img'] = $this->upload($request,'img');
        // dd($info);
        $arr = Ads::insert($info);
        if ($arr){
            echo 1;
        //    return redirect('show');
        }else{
            echo 2;
        }
    }
    /**文件上传 */
    public function upload(Request $request,$filename){
        if ($request->hasFile($filename) && $request->file($filename)->isValid()) {
            $photo = $request->file($filename);
            // $extension = $photo->extension();
            // $store_result = $photo->store('photo');
            $store_result = $photo->store('uploads/'.date('Ymd'));
            return $store_result;
        }
        exit('未获取到上传文件或上传过程出错');
    }

    /**展示 */
    public function show(Request $request){
        $title=empty($_GET['title'])?"":$_GET['title'];

    //    dd($username);
        $where = [];
        if ($title??''){
            $where[] = ['title','like',"%$title%"];
        }
        $arr = Ads::where($where)
            ->where('is_show',1)
            ->select()
            ->paginate(3);
    //    dd($arr);
        return view('ads.show',['arr'=>$arr,'title'=>$title]);
    }

    /**删除 */
    public function del(Request $request){
        $del_id = $request->input('del_id');
        $data = [
            'is_show'=>2,
        ];
        $arr = Ads::where('id',$del_id)->update($data);
        if($arr){
            $arr = ['status'=>1,'msg'=>'删除成功'];
            return $arr;
        }else{
            $arr = ['status'=>0,'msg'=>'删除失败'];
            return $arr;
        }
    }

    /**修改展示 */
    public function upd(Request $request){
        $del_id = $request->input('del_id');
        
        $arr = Ads::where('id','=',$del_id)->first();
        // var_dump($arr);
        return view('ads.update',['arr'=>$arr]);
    }

    /**修改执行 */
    public function update(StoreAdsPost $request){
        $data = $request->input();
        $id = $request->input('id');
        // var_dump($id);
        $data['img'] = $this->upload($request,'img');

        $where=[
            'id'=>$id
        ];

        $arr = Ads::where($where)->update($data);
        // var_dump($arr);
        if($arr){
            echo '1';
            return redirect('show');
        }else{
            echo '2';
        }
    }






}
