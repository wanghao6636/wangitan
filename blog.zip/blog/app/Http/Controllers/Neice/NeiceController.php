<?php

namespace App\Http\Controllers\Neice;

use Illuminate\Http\Request;
use App\Http\Requests\StoreNeicePost;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;


use Illuminate\Support\Facades\Cache;

class NeiceController extends Controller
{
    /**添加展示 */
    public function add(){
        return view('neice.add');
    }

    /**添加执行 */
    public function adddo(StoreNeicePost $request){
        $data = $request->input();
        $data['img'] = $this->upload($request,'img');
        // dd($data);
        $arr = DB::table('neice')->insert($data);
        if ($arr) {
            echo 1;
            return redirect('show');
        }else{
            echo 2;
        }
    }
     /**文件上传 */
    public function upload(Request $request,$filename){
        if ($request->hasFile($filename) && $request->file($filename)->isValid()) {
            $photo = $request->file($filename);
            // $extension = $photo->extension();
            // $store_result = $photo->store('photo');
            $store_result = $photo->store('uploads/'.date('Ymd'));
            return $store_result;
        }
        exit('未获取到上传文件或上传过程出错');
    }

    /*展示 */
    public function show(Request $request){
        $username=empty($_GET['username'])?"":$_GET['username'];
        $page=empty($_GET['page'])?1:$_GET['page'];
        // dd($page);

        $where = [];
        if ($username??''){
            $where[] = ['username','like',"%$username%"];
        }    
    
        $key=$page.$username;
        $arr = Cache::get($key);
        var_dump($arr);
        
        if (!$arr) {
            // if(!empty($username)){
            //     $arr = DB::table('neice')
            //         ->where($where)
            //         ->where('is_show','显示')
            //         ->select()
            //         ->paginate(3);
            // }else{
            //     $arr = DB::table('neice')
            //         ->where($where)
            //         ->where('is_show','显示')
            //         ->select()
            //         ->paginate(3);
            // }
        //    DB::enableQueryLog();
            $arr = DB::table('neice')
                    ->where($where)
                    ->where('is_show','显示')
                    ->select()
                    ->paginate(3);
            // dd(\DB::getQueryLog());
            // $memcache->set($key,$arr,MEMCACHE_COMPRESSED,time()+600);
            Cache::put($key, $arr, 2);
        }
        // var_dump($arr);
        return view('neice.show',['arr'=>$arr,'username'=>$username]);
    }

    /**删除（逻辑） */
    public function del(Request $request){
        $del_id = $request->input('del_id');
        // var_dump($del_id);
        $info = [
            'is_show'=>'不显示'
        ];

        $arr = DB::table('neice')->where('id',$del_id)->update($info);
        // var_dump($arr);
        if($arr){
            $arr = ['status'=>1,'msg'=>'删除成功'];
            return $arr;
        }else{
            $arr = ['status'=>2,'msg'=>'删除失败'];
            return $arr;
        }
    }

    /**修改展示 */
    public function upd(Request $request){
        $del_id = $request->input('del_id');
        // var_dump($del_id);
        $arr = DB::table('neice')->where('id',$del_id)->first();

        return view('neice.update',['arr'=>$arr]);
    }
    /**修改执行 */
    public function update(StoreNeicePost $request){
        $data = $request->input();
        $id = $request->input('id');
        // var_dump($id);
        $where = [
            'id'=>$id
        ];
        $arr = DB::table('neice')->where($where)->update($data);
        // var_dump($arr);
        if ($arr) {
            echo 1;
            return redirect('show');
        }else{
            echo 2;
        }
    }

    /**清空缓存 */
    public function mem(Request $request){
        $bol=Cache::flush();
        if($bol){
            $arr = ['status'=>1,'msg'=>'清除成功'];
            return $arr;
        }else{
            $arr = ['status'=>0,'msg'=>'清除失败'];
            return $arr;
        }
    }

}
