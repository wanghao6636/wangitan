<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<div>用户修改</div><hr>
<table>
    @if($errors->any()) 
    <div class="alert alert-danger">
    <ul>
    @foreach ($errors->all() as $error)
    <li>{{ $error }}</li>
    @endforeach
    </ul>
    </div>
    @endif
    <form action="update" method="post" enctype="multipart/form-data">
        <input type="hidden" name="id" value="<?php echo $arr->id?>">

        <p>账号：<input type="text" name="username" value="<?php echo $arr->username ?>"></p>

        <p>密码：<input type="password" name="pwd" id="pwd" ></p>

        <p>确认密码：<input type="password" name="pwds" id="pwds"></p>

        <p>手机号：<input type="text" name="tel" value="<?php echo $arr->tel ?>"></p>

        <p>

            @if ($arr->sex == 1)
                男<input type="radio" name="sex" value="1" checked>
                女<input type="radio" name="sex" value="2">
            @else
                男<input type="radio" name="sex" value="1">
                女<input type="radio" name="sex" value="2"checked>
            @endif

        </p>

        <p><input type="file" name="img"></p>

        <p><input type="button" value="修改"></p>

    </form>

</table>
</body>
</html>
<script src="js/jquery-3.2.1.min.js"></script>
<script>
   $("input[type=button]").click(function(){
        var pwd = $('#pwd').val();
        var pwds = $("#pwds").val();
        if(pwd){
            $('#pwd').attr('name','pwd');
           
        }
        if(pwds){
            $('#pwds').attr('name','pwds');
           
        }
        $('form').submit();
    })

</script>