<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\validation\Rule;

class StoreNeicePost extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'username' => [
                'required',
                'regex:/^[a-zA-Z0-9_\u4e00-\u9fa5]+$/',
                Rule::unique('neice')->ignore(request()->id,'id'),
            ],
            'https' => [
                'required',
                'regex:/(http|https):\/\/([\w.]+\/?)\S*/',
                Rule::unique('neice')->ignore(request()->id,'id'),
            ],
            'content' => [
                'required',
                'max:100',
                'min:5',
            ],
        ];
    }

    public function messages(){
        return [
            'username.required'=>'网站名称必填',
            'username.unique'=>'网站名称已存在',
            'username.regex'=>'网站名称格式为中文，字母，数字，下划线',

            'https.required'=>'网站网址号必填',
            'https.unique'=>'网站网址已存在',
            'https.regex'=>'网站网址格式不符合 如:http://www.baidu.com',

            'content.required'=>'内容必填',
            'content.max'=>'内容最大为100位',
            'content.min'=>'内容最小为5位',
        ];
    }
}
