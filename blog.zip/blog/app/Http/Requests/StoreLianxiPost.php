<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\validation\Rule;

class StoreLianxiPost extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        
        return [
            'username' => [
                'required',
                'max:15',
                'min:2',
                'regex:/^[a-zA-Z0-9_-]{4,16}$/',
                Rule::unique('lianxi')->ignore(request()->id,'id'),
            ],
            'pwd' => 'required|sometimes|min:6|max:15|alpha_dash',
            'pwds'=>'required|same:pwd',
            'tel' => [
                'required',
                'regex:/^1[34578][0-9]{9}$/',
            ],
        ];
    }

    public function messages(){
        return [
            'username.unique'=>'用户名已存在',
            'username.required'=>'用户名必填',
            'username.max'=>'用户名最大为15位',
            'username.min'=>'用户名最小为2位',
            'username.regex'=>'用户名格式为数字，字母下，划线',
            'pwd.required'=>'密码必填',
            'pwd.min'=>'密码最小为6位',
            'pwd.max'=>'密码最大为15位',
            'pwds.required'=>'确认密码必填',
            'pwds.same'=>'确认密码不一致',
            'tel.required'=>'手机号必填',
            'tel.regex'=>'手机号格式不符合',
        ];
    }
}
