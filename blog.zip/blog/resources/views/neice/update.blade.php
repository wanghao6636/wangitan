<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="layui/css/layui.css"  media="all">
    <title>Document</title>
</head>
<body>
<fieldset class="layui-elem-field layui-field-title" style="margin-top: 30px;">
  <legend>修改友情链接</legend>
<br>
<br>
    @if($errors->any())
    <div class="alert alert-danger">
    <ul>
    @foreach ($errors->all() as $error)
    <li>{{ $error }}</li>
    @endforeach
    </ul>
    </div>
    @endif

    <form action="update" method="post" enctype="multipart/form-data">
    <input type="hidden" name="id" value="{{$arr->id}}">
    <div class="layui-form-item">
            <label class="layui-form-label">网站名称:</label>
        <div class="layui-input-block">
            <input type="text" name="username" lay-verify="title" autocomplete="off" placeholder="请输入网站名称" class="layui-input" value="{{$arr->username}}">
        </div>
    </div>

    <div class="layui-form-item">
            <label class="layui-form-label">网站网址:</label>
        <div class="layui-input-block">
            <input type="text" name="https" lay-verify="title" autocomplete="off" placeholder="请输入网站网址" class="layui-input" value="{{$arr->https}}">
        </div>
    </div>

    <div class="layui-form-item">
            <label class="layui-form-label">链接类型</label>
        <div class="layui-input-block">
        @if($arr->content=='LOGO链接')
            <input type="radio" name="statue" value="LOGO链接" checked="">LOGO链接
            <input type="radio" name="statue" value="文字链接" >文字链接
        @else
            <input type="radio" name="statue" value="LOGO链接" >LOGO链接
            <input type="radio" name="statue" value="文字链接" checked="">文字链接
        @endif
        </div>
    </div>

    <div class="layui-form-item">
            <label class="layui-form-label">联系人:</label>
        <div class="layui-input-block">
            <input type="text" name="contacts" lay-verify="title" autocomplete="off" placeholder="请输入联系人" class="layui-input" value="{{$arr->contacts}}">
        </div>
    </div>

    <div class="layui-form-item layui-form-text">
            <label class="layui-form-label">内容:</label>
        <div class="layui-input-block">
            <textarea placeholder="请输入内容" class="layui-textarea" name="content" value="{{$arr->username}}">{{$arr->content}}</textarea>
        </div>
    </div>

    <div class="layui-form-item">
            <label class="layui-form-label">图片:</label>
        <div class="layui-input-block">
            <input type="file" name="img">
        </div>
    </div>

    <div class="layui-form-item">
            <label class="layui-form-label">是否展示</label>
        <div class="layui-input-block">
        @if($arr->is_show=='显示')
            <input type="radio" name="is_show" value="显示" checked="">是
            <input type="radio" name="is_show" value="不显示" >否
        @else
            <input type="radio" name="is_show" value="显示" >是
            <input type="radio" name="is_show" value="不显示" checked="">否
        @endif
        </div>
    </div>

    <div class="layui-form-item">
        <div class="layui-input-block">
            <button class="layui-btn layui-btn-normal layui-btn-radius">修改</button>
        </div>
    </div>

    </form>
</body>
</html>