<!DOCTYPE html>
<html lang="zh-cn">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="Author" contect="http://www.webqin.net">
    <title>三级分销</title>
    <link rel="shortcut icon" href="images/favicon.ico" />
    <link rel="stylesheet" href="layui/css/layui.css"  media="all">
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/response.css" rel="stylesheet">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="http://cdn.bootcss.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="http://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
    <div class="maincont">
     <header>
      <a href="javascript:history.back(-1)" class="back-off fl"><span class="glyphicon glyphicon-menu-left"></span></a>
      <div class="head-mid">
       <h1>产品详情</h1>
      </div>
     </header>
     <div id="sliderA" class="slider">
      <img src="images/image1.jpg" />
      <img src="images/image2.jpg" />
      <img src="images/image3.jpg" />
      <img src="images/image4.jpg" />
      <img src="images/image5.jpg" />
     </div><!--sliderA/-->
    <table class="jia-len">
     @foreach ($arr as $v)
      <tr>
        
       <th><strong class="orange">{{$v->goods_selfprice}}</strong></th>
       <td>
        <input type="text" class="spinnerExample" />
       </td>
      </tr>
      <tr>
       <td>
        <strong>{{$v->goods_name}}</strong>
        <p class="hui" goods_id="{{$v->goods_id}}">富含纤维素，平衡每日膳食</p>
       </td>
       <td align="right">
        <a href="javascript:;" class="shoucang"><span class="glyphicon glyphicon-star-empty"></span></a>
       </td>
      </tr>
      
      @endforeach
      <a href="javascript:;" class="layui-btn layui-btn-sm layui-btn-normal pro_info">加入购物车</a>
      <a href="cart"><span class="glyphicon glyphicon-home"></span></a>
    </table>
     <div class="height2"></div>
     <h3 class="proTitle">商品规格</h3>
     <ul class="guige">
      <li class="guigeCur"><a href="javascript:;">50ML</a></li>
      <li><a href="javascript:;">100ML</a></li>
      <li><a href="javascript:;">150ML</a></li>
      <li><a href="javascript:;">200ML</a></li>
      <li><a href="javascript:;">300ML</a></li>
      <div class="clearfix"></div>
     </ul><!--guige/-->
     <div class="height2"></div>
     <div class="zhaieq">
      <a href="javascript:;" class="zhaiCur">商品简介</a>
      <a href="javascript:;">商品参数</a>
      <a href="javascript:;" style="background:none;">订购列表</a>
      <div class="clearfix"></div>
     </div><!--zhaieq/-->
     <div class="proinfoList">
      <img src="images/image4.jpg" width="636" height="822" />
     </div><!--proinfoList/-->
     <div class="proinfoList">
      暂无信息....
     </div><!--proinfoList/-->
     <div class="proinfoList">
      暂无信息......
     </div><!--proinfoList/-->
     <table class="jrgwc">
        <tr>
          <th>
            <a href="index.html"><span class="glyphicon glyphicon-home"></span></a>
          </th>
        <td>
          
          <a href="javascript:;" class="pro_info">加入购物车</a>
        </td>
        </tr>
    </table>
    </div><!--maincont-->
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/style.js"></script>
    <!--焦点轮换-->
    <script src="js/jquery.excoloSlider.js"></script>
    <script>
		$(function () {
		 $("#sliderA").excoloSlider();
		});
	</script>
     <!--jq加减-->
    <script src="js/jquery.spinner.js"></script>
   <script>
	$('.spinnerExample').spinner({});

  //    $(document).on('click','.increase',function(){
  //      var num = $(this).prev().val();
  //     alert(num);
  //  })
	</script>
  </body>
</html>
<script src="layui/layui.js"></script>
<script>
/**加入购物车 */
$(document).ready(function(){
  layui.use("layer",function(){
    var layer=layui.layer;
    $(".pro_info").click(function(){
      
      var data = {};
      var _this = $(this);
      var goods_id=$('.hui').attr('goods_id');
      // console.log(goods_id);
      data.buy_number = 1;
      data.goods_id = goods_id;
      // alert(goods_id)
      var url = "cartadd";
      $.ajax({
        type: "post",
        data: data,
        dataType: "json",
        url: url,
        success: function (msg) {
          if(msg.status==1){
              layer.msg(msg.msg);
              // location.href='login';
          }else if(msg.status==3){
                layer.msg(msg.msg);
                location.href='login';
          }else{
            layer.msg(msg.msg);
            location.href='index';
          }     
        }  
      });
    })
  })
})
</script>