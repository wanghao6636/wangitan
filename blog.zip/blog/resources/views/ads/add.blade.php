<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="layui/css/layui.css"  media="all">
    <title>Document</title>
</head>
<body>
<fieldset class="layui-elem-field layui-field-title" style="margin-top: 30px;">
  <legend>公告添加</legend>
<br>
<br>
    @if($errors->any())
    <div class="alert alert-danger">
    <ul>
    @foreach ($errors->all() as $error)
    <li>{{ $error }}</li>
    @endforeach
    </ul>
    </div>
    @endif

    <form action="adddo" method="post" enctype="multipart/form-data">

    <div class="layui-form-item">
            <label class="layui-form-label">标题:</label>
        <div class="layui-input-block">
            <input type="text" name="title" lay-verify="title" autocomplete="off" placeholder="请输入标题" class="layui-input">
        </div>
    </div>

    <div class="layui-form-item">
            <label class="layui-form-label">关键词:</label>
        <div class="layui-input-block">
            <input type="text" name="keyword" lay-verify="title" autocomplete="off" placeholder="请输入关键词" class="layui-input">
        </div>
    </div>

    <div class="layui-form-item layui-form-text">
            <label class="layui-form-label">内容:</label>
        <div class="layui-input-block">
            <textarea placeholder="请输入内容" class="layui-textarea" name="content"></textarea>
        </div>
    </div>

    <div class="layui-form-item">
            <label class="layui-form-label">图片:</label>
        <div class="layui-input-block">
            <input type="file" name="img">
        </div>
    </div>

    <div class="layui-form-item">
            <label class="layui-form-label">是否展示</label>
        <div class="layui-input-block">
            <input type="radio" name="is_show" value="1" checked="">是
            <input type="radio" name="is_show" value="2" >否
        </div>
    </div>

    <div class="layui-form-item">
        <div class="layui-input-block">
            <button class="layui-btn layui-btn-normal layui-btn-radius">添加</button>
        </div>
    </div>

    </form>
</body>
</html>