<?php

namespace App\Http\Controllers\Login;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class RegController extends Controller
{
    public function reg(){
        return view('login.reg');
    }

    public function register(Request $request){
        $data = $request->input();

        $user_tel=$data['user_tel'];
        $user_pwd=$data['user_pwd'];
        $user_pwds=$data['user_pwds'];

         if($user_pwd != $user_pwds){
            $arr = array(
                'status'=>0,
                "msg"=>"密码不一致",
            );
            return $arr;
        }

         $arr = DB::table('index_register')->where('user_tel',$user_tel)->first();
         if(!empty($arr)){
             $arr = array(
                 'status'=>0,
                 "msg"=>"手机号已存在"
             );
             return $arr;
         }

         $info=[
            'user_tel'=>$user_tel,
            'user_pwd'=>$user_pwd
         ];
        // dd($info);
         $res=DB::table('index_register')->insert($info);
         if($res){
             echo 1;
            //  return redirect('login');
         }else{
             echo 2;
        }
    }
    // public function getcode(Request $request){
    //     $tel = $request->input("tel");
    //             // var_dump($tel);exit;
    //     // $num = rand(1000,9999);
    //     $num = '1111';
    //     // $obj = new \send();
    //     $bol =$tel.$num;
    //     if ($bol == 100) {
    //         $arr = array(
    //             'tel'=>$tel,
    //             'code'=>$num,
    //             'timeout'=>time()+360,

    //         );
    //         $bol = DB::table('user_code')->insert($arr);
    //         var_dump($arr);exit;
    //         var_dump($bol);
    //     }
    // }
}
