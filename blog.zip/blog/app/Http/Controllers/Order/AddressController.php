<?php

namespace App\Http\Controllers\Order;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class AddressController extends Controller
{
    /**地址展示 */
    public function site(){
        $where = [
            'pid'=>0,
        ];
        $arr = DB::table('order_area')->where($where)->get();

        return view('order.address',['arr'=>$arr]);
    }

    /** 三级联动获取区域 */
    public function area(Request $request){
        $id = $request->input('id');

        // dd($id);
        $info=$this->areaInfo($id);
        echo json_encode($info);
    }
    /** 获取区域信息 */
    public function areaInfo($id){

        $where=[
            'pid'=>$id
        ];
        $info=DB::table('order_area')->where($where)->get();
        return $info;
    } 

    /**地址添加 */
    public function siteadd(Request $request){
        $session_id = $request->session()->get('user_id');

        $data = $request->input();
        if ($session_id) {
            $info = [
                'user_id'=>$session_id,
                'add_name' => $data['add_name'],
                'add_details' => $data['add_details'],
                'add_tel' => $data['add_tel'],
                'add_province'=>$data['add_province'],
                'add_city'=>$data['add_city'],
                'add_district'=>$data['add_district'],
                'status'=>$data['status'],
                'create_time'=>time(),
            ];
        $arr = DB::table('order_address')->insert($info);
            if($arr){
                $arr = ['status'=>1,'msg'=>'保存成功'];
                return $arr;
            }
        }else{
            return  array('status'=>3,"msg"=>"请先登录");
        }
    }

    /**所有地址展示 */
    public function adrshow(){
        $arr = DB::table('order_address')->get();
        return view('order.adrshow',['arr'=>$arr]);
    }
    /**设置默认地址 */
    public function defalt(Request $request){
        $add_id = $request->input('add_id');
        $session_id  = $request->session()->get('user_id');

        if ($session_id) {
            $ainfo = [
                
                'status'=>2,
            ];
            $binfo = [
                
                'status'=>1,
            ];
            // print_r($data);exit;
            $res = DB::table('order_address')->where('user_id',$session_id)->update($ainfo);
            $arr = DB::table('order_address')->where('add_id',$add_id)->update($binfo);
            if($res){
                $arr = ['status'=>1,'msg'=>'设置成功'];
                return $arr;
            }else{
                $arr = ['status'=>0,'msg'=>'设置失败'];
                return $arr;
            }
        }else{
            $arr = ['status'=>3,'msg'=>'设置失败'];
            return $arr;
        }
    }
    /**删除地址 */
    public function addressdel(Request $request){
        $session_id = $request->session()->get('user_id');
        if (!empty($session_id)) {
            $add_id = $request->input('add_id');
            // var_dump($id);exit;
            // if (empty($address_id)) {
            //     $arr = ['status'=>0,'msg'=>'请选择要删除的商品'];
            //     return $arr;
            // }
            $data = [
                'is_del'=>2,
            ];
            $arr = DB::table('order_address')->where('add_id',$add_id)->update($data);
            if($arr){
                $arr = ['status'=>1,'msg'=>'删除成功'];
                return $arr;
            }else{
                $arr = ['status'=>0,'msg'=>'删除失败'];
                return $arr;
            }
        }
    }
}