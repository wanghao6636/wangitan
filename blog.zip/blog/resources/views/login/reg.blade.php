<!DOCTYPE html>
<html lang="zh-cn">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="Author" contect="http://www.webqin.net">
    <title>三级分销</title>
    <link rel="shortcut icon" href="images/favicon.ico" />
    
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/response.css" rel="stylesheet">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="http://cdn.bootcss.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="http://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <script src="http://www.jq22.com/jquery/jquery-1.10.2.js"></script>
    <script src="js/leftTime.min.js"></script>
  </head>
  <body>
    <div class="maincont">
     <header>
      <a href="javascript:history.back(-1)" class="back-off fl"><span class="glyphicon glyphicon-menu-left"></span></a>
      <div class="head-mid">
       <h1>会员注册</h1>
      </div>
     </header>
     <div class="head-top">
      <img src="images/head.jpg" />
     </div><!--head-top/-->
     <form action="register" method="post" class="reg-login">
      <h3>已经有账号了？点此<a class="orange" href="login">登陆</a></h3>
      <div class="lrBox">
       <div class="lrList"><input type="text" placeholder="输入手机号码或者邮箱号" id="tel" name="user_tel"/></div>
       <div class="lrList2"><input type="text" placeholder="输入短信验证码"  id="code" /><button type="button" id="dateBtn1">获取验证码</button></div>
       <div class="lrList"><input type="password" placeholder="设置新密码（6-18位数字或字母）" id="pwd" name="user_pwd" /></div>
       <div class="lrList"><input type="password" placeholder="再次输入密码" name="user_pwds" id="pwds" /></div>
      </div><!--lrBox/-->
      <div class="lrSub">
       <!-- <input type="submit" value="立即注册" /> -->
       <a href="javascript:;" id="btnNext">立即注册</a>
      </div>
     </form><!--reg-login/-->
     <div class="height1"></div>
     <div class="footNav">
      <dl>
       <a href="index.html">
        <dt><span class="glyphicon glyphicon-home"></span></dt>
        <dd>微店</dd>
       </a>
      </dl>
      <dl>
       <a href="prolist.html">
        <dt><span class="glyphicon glyphicon-th"></span></dt>
        <dd>所有商品</dd>
       </a>
      </dl>
      <dl>
       <a href="car.html">
        <dt><span class="glyphicon glyphicon-shopping-cart"></span></dt>
        <dd>购物车 </dd>
       </a>
      </dl>
      <dl>
       <a href="user.html">
        <dt><span class="glyphicon glyphicon-user"></span></dt>
        <dd>我的</dd>
       </a>
      </dl>
      <div class="clearfix"></div>
     </div><!--footNav/-->
    </div><!--maincont-->
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/style.js"></script>
    <script src="layui/layui.js"></script> 
    <!-- <script src="js/jquery-1.11.2.min.js"></script> -->
      <script>
$(document).ready(function(){
  layui.use("layer",function(){
        var layer=layui.layer;
    $('#btnNext').click(function(){
    	if($('#tel').val()==''){
    		layer.msg('请输入您的手机号！');
    	}else if($('#pwd').val()==''){
    		layer.msg('请输入您的密码!');
    	}else if($('#pwds').val()==''){
    		layer.msg('请您再次输入密码！');
    	}else{
            var user_tel=$('#tel').val();
            var user_pwd=$('#pwd').val();
            var user_pwds=$('#pwds').val();
            // var user_code=$('#code').val();
            $.post(
                'register',
               {user_tel:user_tel,user_pwd:user_pwd,user_pwds:user_pwds},
               function(res){
                  //  console.log(res);
                 if(res==1){
                    layer.msg(res.msg);
                    location.href='login';
                }else{
                    layer.msg(res.msg);
                    location.href='reg';
                    }  
                }    
            )
        }
    })
  })
})
</script>


  </body>
</html>
<script type="text/javascript">
    // $(function(){
    //     //60秒倒计时
    //     $("#dateBtn1").on("click",function(){
    //         var _this=$(this);
    //         if(!$(this).hasClass("on")){
    //             var data = {};
    //             var url = "getcode";
    //             tel = $("#tel").val();
    //             data.tel = tel;
    //             $.ajax({
    //                 type : "post",
    //                 data : data,
    //                 url : url,
    //                 dataType : "json",
    //                 success:function(msg){

    //                 }
    //             })
    //             $.leftTime(60,function(d){
    //                 if(d.status){
    //                     _this.addClass("on");
    //                     _this.html((d.s=="00"?"60":d.s)+"秒后重新获取");
    //                 }else{
    //                     _this.removeClass("on");
    //                     _this.html("获取验证码");
    //                 }
    //             });
    //         }
    //     });
    // });
</script>
