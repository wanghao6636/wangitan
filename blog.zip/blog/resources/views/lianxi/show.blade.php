<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <div>用户添加</div><hr>
    <table>
    @if($errors->any())
    <div class="alert alert-danger">
    <ul>
    @foreach ($errors->all() as $error)
    <li>{{ $error }}</li>
    @endforeach
    </ul>
    </div>
    @endif

        <form action="add" method="post" enctype="multipart/form-data">

        <p>账号：<input type="text" name="username"></p>

        <p>密码：<input type="password" name="pwd"></p>

        <p>确认密码：<input type="password" name="pwds"></p>

        <p>手机号：<input type="text" name="tel"></p>

        <p>
            男<input type="radio" name="sex" value="1">
            女<input type="radio" name="sex" value="2">
        </p>

        <p><input type="file" name="img"></p>

        <p><input type="submit" value="添加"></p>

        </form>

    </table>
</body>
</html>