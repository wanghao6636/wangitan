<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\validation\Rule;

class StoreAdsPost extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'title' => [
                'required',
                'max:60',
                'min:5',
                'regex:/^[\x{4e00}-\x{9fa5}A-Za-z0-9]+$/u',
                Rule::unique('lianxi')->ignore(request()->id,'id'),
            ],
            'keyword' => [
                'required',
                'max:15',
                'min:2',
                'regex:regex:/^[\x{4e00}-\x{9fa5}A-Za-z0-9]+$/u',
            ],
            'content' => [
                'required',
                'max:100',
                'min:5',
            ],
        ];
        
    }

    public function messages(){
        return [
            'title.unique'=>'标题已存在',
            'title.required'=>'标题必填',
            'title.max'=>'标题最大为60位',
            'title.min'=>'标题最小为5位',
            'title.regex'=>'标题格式为汉字，数字，字母下，划线',

            'keyword.required'=>'关键字号必填',
            'keyword.regex'=>'关键字格式不符合',
            'keyword.max'=>'标题最大为15位',
            'keyword.min'=>'标题最小为2位',

            'content.required'=>'内容必填',
            'content.max'=>'内容最大为100位',
            'content.min'=>'内容最小为5位',
        ];
    }
}
